

SELECT * FROM products;

